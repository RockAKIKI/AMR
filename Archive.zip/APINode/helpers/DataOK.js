function DataOK(message, data)
{
    return {
        message:message, 
        data:data
    }
}

module.exports = DataOK;