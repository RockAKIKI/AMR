import React from 'react';
import './Inscription.css';

const Inscription = () => {
    return (
        <div>
            Inscription
        </div>
    );
};

export default Inscription;